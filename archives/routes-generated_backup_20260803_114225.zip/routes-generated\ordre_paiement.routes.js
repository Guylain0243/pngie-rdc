// =====================================================================
// ROUTEUR GENERE AUTOMATIQUEMENT par government-builder.js
// Entite : undefined  (table : ordre_paiement)
// Scope  : INSTITUTION
// NE PAS MODIFIER A LA MAIN - regenerer via government-builder.js
// si les metadonnees changent.
// =====================================================================

const express = require('express');
const crypto = require('crypto');
const db = require('../src/db');
const { verifierRegles } = require('../src/rule-engine');
const { enregistrerEvenement, historique } = require('../src/event-engine');
const { exigerPermission } = require('../src/security-engine');
const requestContext = require('../src/request-context');

const router = express.Router();

const CHAMPS = ["beneficiaire","montant","institution","statut"];
const CHAMPS_OBLIGATOIRES = ["beneficiaire","institution"];

function validerPayload(body) {
    const manquants = CHAMPS_OBLIGATOIRES.filter(c => body[c] === undefined || body[c] === null || body[c] === '');
    return manquants;
}

function institutionCourante() {
    const ctx = requestContext.getContext();
    return ctx ? ctx.institutionId : null;
}

// LISTE
router.get('/ordre_paiements', exigerPermission('ordre_paiement', 'READ'), async (req, res) => {
    try {
        const instId = institutionCourante();
        if (!instId) return res.status(403).json({ error: 'Institution non resolue pour cet utilisateur' });
        const rows = await db.all(`SELECT * FROM ordre_paiement WHERE institution_id = ? ORDER BY created_at DESC`, [instId]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DETAIL
router.get('/ordre_paiements/:id', exigerPermission('ordre_paiement', 'READ'), async (req, res) => {
    try {
        const instId = institutionCourante();
        if (!instId) return res.status(403).json({ error: 'Institution non resolue pour cet utilisateur' });
        const row = await db.get(`SELECT * FROM ordre_paiement WHERE ordre_paiement_id = ? AND institution_id = ?`, [req.params.id, instId]);
        if (!row) return res.status(404).json({ error: 'undefined introuvable' });
        res.json(row);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// CREATION
router.post('/ordre_paiements', exigerPermission('ordre_paiement', 'CREATE'), async (req, res) => {
    const manquants = validerPayload(req.body);
    if (manquants.length > 0) {
        return res.status(400).json({ error: 'Champs obligatoires manquants', champs: manquants });
    }
    try {
        const instId = institutionCourante();
        if (!instId) return res.status(403).json({ error: 'Institution non resolue pour cet utilisateur' });
        const id = crypto.randomUUID();
        const champsRenseignes = CHAMPS.filter(c => req.body[c] !== undefined);
        const colonnes = ['ordre_paiement_id', ...champsRenseignes, 'institution_id'];
        const valeurs = [id, ...champsRenseignes.map(c => req.body[c]), instId];
        const placeholders = colonnes.map(() => '?').join(', ');
        await db.run(
            `INSERT INTO ordre_paiement (${colonnes.join(', ')}) VALUES (${placeholders})`,
            valeurs
        );
        const row = await db.get(`SELECT * FROM ordre_paiement WHERE ordre_paiement_id = ?`, [id]);
        await enregistrerEvenement('ordre_paiement', id, 'CREATION', null, row);
        res.status(201).json(row);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// MODIFICATION
router.put('/ordre_paiements/:id', exigerPermission('ordre_paiement', 'UPDATE'), async (req, res) => {
    try {
        const instId = institutionCourante();
        if (!instId) return res.status(403).json({ error: 'Institution non resolue pour cet utilisateur' });
        const existant = await db.get(`SELECT * FROM ordre_paiement WHERE ordre_paiement_id = ? AND institution_id = ?`, [req.params.id, instId]);
        if (!existant) return res.status(404).json({ error: 'undefined introuvable' });

        // Verification des regles metier (meta_rule) avant toute modification
        const violations = await verifierRegles('ordre_paiement', 'AVANT_MODIFICATION', existant, req.body);
        if (violations.length > 0) {
            return res.status(409).json({ error: 'Regle(s) metier violee(s)', violations });
        }

        const champsAModifier = CHAMPS.filter(c => req.body[c] !== undefined);
        if (champsAModifier.length === 0) {
            return res.status(400).json({ error: 'Aucun champ a modifier' });
        }
        const setClause = champsAModifier.map(c => `${c} = ?`).join(', ');
        const valeurs = champsAModifier.map(c => req.body[c]);
        await db.run(
            `UPDATE ordre_paiement SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE ordre_paiement_id = ? AND institution_id = ?`,
            [...valeurs, req.params.id, instId]
        );
        const row = await db.get(`SELECT * FROM ordre_paiement WHERE ordre_paiement_id = ?`, [req.params.id]);
        await enregistrerEvenement('ordre_paiement', req.params.id, 'MODIFICATION', existant, row);
        res.json(row);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// SUPPRESSION
router.delete('/ordre_paiements/:id', exigerPermission('ordre_paiement', 'DELETE'), async (req, res) => {
    try {
        const instId = institutionCourante();
        if (!instId) return res.status(403).json({ error: 'Institution non resolue pour cet utilisateur' });
        const existant = await db.get(`SELECT * FROM ordre_paiement WHERE ordre_paiement_id = ? AND institution_id = ?`, [req.params.id, instId]);
        if (!existant) return res.status(404).json({ error: 'undefined introuvable' });
        await db.run(`DELETE FROM ordre_paiement WHERE ordre_paiement_id = ? AND institution_id = ?`, [req.params.id, instId]);
        await enregistrerEvenement('ordre_paiement', req.params.id, 'SUPPRESSION', existant, null);
        res.status(204).send();
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// HISTORIQUE (genere automatiquement par le moteur d'evenements)
router.get('/ordre_paiements/:id/historique', exigerPermission('ordre_paiement', 'READ'), async (req, res) => {
    try {
        const evenements = await historique('ordre_paiement', req.params.id);
        res.json(evenements);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
